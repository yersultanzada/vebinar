<? if ($_GET['status'] == 'success') { ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Бесплатный вебинар: Как научиться создавать сайты с нуля</title>
    <meta name="description" content="Научись создавать профессиональные сайты с нуля и зарабатывай на этом от 300 000 тг в месяц">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">
    <meta http-equiv="pragma" content="no-cache">
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this project -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700;900&display=swap" rel="stylesheet">
    <!-- Custom styles for this project -->
    <link href="css/project.min.css" rel="stylesheet">
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-M64J3W8');</script>
    <!-- End Google Tag Manager -->
</head>
<body id="page-top">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M64J3W8"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- About -->
<section class="masthead thank-you p-0">
    <div class="container">
        <div class="row block-header">
            <a href="/"><img src="img/logo-dark.png" alt=""></a>
            <div>БЕСПЛАТНЫЙ ВЕБИНАР</div>
            <div>9 июля - 19:00 Аст</div>
        </div>
    </div>
</section>
<section id="thank-you" class="pt-3">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center mb-5">
                <h2 class="wt-section-title mb-3">Отлично!</h2>
                <div class="thank-you-text">
                    Вы успешно зарегистрировались и я отправлю все подробности доступа к вебинару ближе к дате.
                </div>
            </div>
            <div class="col-lg-6 mb-4 mb-lg-0">
                <div class="responsive-video">
                    <iframe width="100%" height="377" src="https://www.youtube.com/embed/1AwlVagn2Xk" frameborder="0" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
            <div class="col-lg-5 offset-lg-1">
                <h2 class="wt-section-title wt-text-green mb-3">Как получить максимум</h2>
                <div class="block-item">
                    <div class="item-dig">1</div>
                    <div class="item-text">
                        Поставьте напоминание в телефон на <strong>9 июля, 19:00 Аст</strong>
                    </div>
                </div>
                <div class="block-item">
                    <div class="item-dig">2</div>
                    <div class="item-text">
                        Переходите в <strong>телеграм</strong>, там будет много полезной информации!
                    </div>
                </div>
                <div class="mt-3 text-center">
                    <a href="#"><img src="img/Telegram.png" width="50" alt=""></a>
                </div>
                <div class="mt-3 text-center">
                    <a href="#">Нажмите сюда, чтобы скачать обещенный гайд</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bootstrap core JavaScript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.lazyloadxt/1.1.0/jquery.lazyloadxt.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Plugin JavaScript -->
<script type="text/javascript" src="//cdn.jsdelivr.net/jquery.lazy/1.7.1/jquery.lazy.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/jquery.lazy/1.7.1/plugins/jquery.lazy.youtube.min.js"></script>
<!-- Custom scripts for this template -->
<script src="js/project.min.js"></script>
</body>
</html>
<? } else {
    header ("Location: /");
} ?>